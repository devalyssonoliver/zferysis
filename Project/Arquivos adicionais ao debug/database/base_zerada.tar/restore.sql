--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.25
-- Dumped by pg_dump version 9.5.25

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.colaboradores DROP CONSTRAINT setor_fkey;
ALTER TABLE ONLY public.lancamento_ferias DROP CONSTRAINT codigo_colaborador_fkey;
DROP TRIGGER trigger_validar_ferias ON public.lancamento_ferias;
DROP TRIGGER trigger_atualizar_periodos ON public.colaboradores;
DROP TRIGGER trigger_aplicar_md5 ON public.usuarios;
DROP INDEX public.idx_periodo_ferias;
DROP INDEX public.idx_colaborador_ano;
DROP INDEX public.idx_codigo_colaborador;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.setores DROP CONSTRAINT setores_pkey;
ALTER TABLE ONLY public.lancamento_ferias DROP CONSTRAINT lancamento_ferias_pkey;
ALTER TABLE ONLY public.colaboradores DROP CONSTRAINT colaboradores_pkey;
DROP VIEW public.vusuarios;
DROP TABLE public.usuarios;
DROP SEQUENCE public.usuario_codigo_seq;
DROP TABLE public.setores;
DROP SEQUENCE public.setor_codigo_seq;
DROP TABLE public.lancamento_ferias;
DROP SEQUENCE public.ferias_lancamento_codigo_seq;
DROP TABLE public.configuracoes;
DROP TABLE public.colaboradores;
DROP SEQUENCE public.colaborador_codigo_seq;
DROP FUNCTION public.validar_ferias();
DROP FUNCTION public.atualizar_periodos_colaborador();
DROP FUNCTION public.aplicar_md5();
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: aplicar_md5(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.aplicar_md5() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.senha := MD5(NEW.senha);
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.aplicar_md5() OWNER TO postgres;

--
-- Name: atualizar_periodos_colaborador(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.atualizar_periodos_colaborador() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verificar se data_contrato não é nula
    IF NEW.data_contrato IS NOT NULL THEN
        -- Calcular o período aquisitivo (12 meses após a data de contrato)
        NEW.periodo_aquisitivo := NEW.data_contrato + INTERVAL '12 months';
        
        -- Calcular o período concessivo (1 dia após o período aquisitivo)
        NEW.periodo_concessivo := NEW.periodo_aquisitivo + INTERVAL '1 day';
    ELSE
        -- Caso a data_contrato seja nula, pode-se definir um valor padrão ou lançar um erro
        RAISE EXCEPTION 'data_contrato não pode ser nula';
    END IF;
    
    -- Retornar os dados atualizados
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.atualizar_periodos_colaborador() OWNER TO postgres;

--
-- Name: validar_ferias(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validar_ferias() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_ferias INTEGER := 0; 
    total_ferias_config INTEGER;
BEGIN
    
    IF EXISTS (
        SELECT 1
        FROM lancamento_ferias
        WHERE codigo_colaborador = NEW.codigo_colaborador
          AND (
              (NEW.data_inicio BETWEEN data_inicio AND data_fim) OR
              (NEW.data_fim BETWEEN data_inicio AND data_fim) OR
              (data_inicio BETWEEN NEW.data_inicio AND NEW.data_fim) OR
              (data_fim BETWEEN NEW.data_inicio AND NEW.data_fim)
          )
    ) THEN
        RAISE EXCEPTION 'O colaborador já tem férias no período informado.';
    END IF;


    SELECT total_ferias_ano INTO total_ferias_config FROM configuracoes LIMIT 1;

    
    SELECT COALESCE(SUM(
                       CASE
                           WHEN EXTRACT(YEAR FROM data_inicio) = EXTRACT(YEAR FROM NEW.data_inicio)
                            THEN (data_fim - data_inicio) + 1
                           ELSE 0
                       END
                   ), 0)
    INTO total_ferias
    FROM lancamento_ferias
    WHERE codigo_colaborador = NEW.codigo_colaborador
      AND EXTRACT(YEAR FROM data_inicio) = EXTRACT(YEAR FROM NEW.data_inicio);

    
    total_ferias := total_ferias + ((NEW.data_fim - NEW.data_inicio) + 1);

    
    IF total_ferias > total_ferias_config THEN
        RAISE EXCEPTION 'O colaborador não pode ter mais de % dias de férias no mesmo ano.', total_ferias_config;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.validar_ferias() OWNER TO postgres;

--
-- Name: colaborador_codigo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colaborador_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colaborador_codigo_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: colaboradores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colaboradores (
    codigo integer DEFAULT nextval('public.colaborador_codigo_seq'::regclass) NOT NULL,
    nome character varying(150) NOT NULL,
    matricula character varying(20),
    codigo_setor integer,
    data_contrato date NOT NULL,
    periodo_aquisitivo date,
    periodo_concessivo date,
    data_cadastro date DEFAULT ('now'::text)::date
);


ALTER TABLE public.colaboradores OWNER TO postgres;

--
-- Name: configuracoes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.configuracoes (
    total_ferias_ano integer
);


ALTER TABLE public.configuracoes OWNER TO postgres;

--
-- Name: ferias_lancamento_codigo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ferias_lancamento_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ferias_lancamento_codigo_seq OWNER TO postgres;

--
-- Name: lancamento_ferias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lancamento_ferias (
    codigo integer DEFAULT nextval('public.ferias_lancamento_codigo_seq'::regclass) NOT NULL,
    codigo_colaborador integer NOT NULL,
    data_inicio date NOT NULL,
    data_fim date NOT NULL,
    ferias_concedidas boolean DEFAULT false
);


ALTER TABLE public.lancamento_ferias OWNER TO postgres;

--
-- Name: setor_codigo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.setor_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.setor_codigo_seq OWNER TO postgres;

--
-- Name: setores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.setores (
    codigo integer DEFAULT nextval('public.setor_codigo_seq'::regclass) NOT NULL,
    descricao character varying(150) NOT NULL,
    ativo boolean DEFAULT true,
    data_cadastro date DEFAULT ('now'::text)::date
);


ALTER TABLE public.setores OWNER TO postgres;

--
-- Name: usuario_codigo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_codigo_seq OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    codigo integer DEFAULT nextval('public.usuario_codigo_seq'::regclass) NOT NULL,
    nome character varying(100) NOT NULL,
    login character varying(100) NOT NULL,
    senha text NOT NULL,
    ativo boolean DEFAULT true,
    data_cadastro date DEFAULT ('now'::text)::date
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: vusuarios; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vusuarios AS
 SELECT usuarios.codigo,
    usuarios.nome,
    usuarios.login,
    usuarios.data_cadastro,
    usuarios.ativo
   FROM public.usuarios;


ALTER TABLE public.vusuarios OWNER TO postgres;

--
-- Name: colaborador_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colaborador_codigo_seq', 10, true);


--
-- Data for Name: colaboradores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colaboradores (codigo, nome, matricula, codigo_setor, data_contrato, periodo_aquisitivo, periodo_concessivo, data_cadastro) FROM stdin;
\.
COPY public.colaboradores (codigo, nome, matricula, codigo_setor, data_contrato, periodo_aquisitivo, periodo_concessivo, data_cadastro) FROM '$$PATH$$/2157.dat';

--
-- Data for Name: configuracoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.configuracoes (total_ferias_ano) FROM stdin;
\.
COPY public.configuracoes (total_ferias_ano) FROM '$$PATH$$/2160.dat';

--
-- Name: ferias_lancamento_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ferias_lancamento_codigo_seq', 1, false);


--
-- Data for Name: lancamento_ferias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lancamento_ferias (codigo, codigo_colaborador, data_inicio, data_fim, ferias_concedidas) FROM stdin;
\.
COPY public.lancamento_ferias (codigo, codigo_colaborador, data_inicio, data_fim, ferias_concedidas) FROM '$$PATH$$/2159.dat';

--
-- Name: setor_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.setor_codigo_seq', 1, false);


--
-- Data for Name: setores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.setores (codigo, descricao, ativo, data_cadastro) FROM stdin;
\.
COPY public.setores (codigo, descricao, ativo, data_cadastro) FROM '$$PATH$$/2156.dat';

--
-- Name: usuario_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_codigo_seq', 3, true);


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (codigo, nome, login, senha, ativo, data_cadastro) FROM stdin;
\.
COPY public.usuarios (codigo, nome, login, senha, ativo, data_cadastro) FROM '$$PATH$$/2153.dat';

--
-- Name: colaboradores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT colaboradores_pkey PRIMARY KEY (codigo);


--
-- Name: lancamento_ferias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lancamento_ferias
    ADD CONSTRAINT lancamento_ferias_pkey PRIMARY KEY (codigo);


--
-- Name: setores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setores
    ADD CONSTRAINT setores_pkey PRIMARY KEY (codigo);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (codigo);


--
-- Name: idx_codigo_colaborador; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_codigo_colaborador ON public.lancamento_ferias USING btree (codigo_colaborador);


--
-- Name: idx_colaborador_ano; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_colaborador_ano ON public.lancamento_ferias USING btree (codigo_colaborador, date_part('year'::text, data_inicio));


--
-- Name: idx_periodo_ferias; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periodo_ferias ON public.lancamento_ferias USING btree (data_inicio, data_fim);


--
-- Name: trigger_aplicar_md5; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_aplicar_md5 BEFORE INSERT OR UPDATE ON public.usuarios FOR EACH ROW EXECUTE PROCEDURE public.aplicar_md5();


--
-- Name: trigger_atualizar_periodos; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_atualizar_periodos AFTER INSERT ON public.colaboradores FOR EACH ROW EXECUTE PROCEDURE public.atualizar_periodos_colaborador();


--
-- Name: trigger_validar_ferias; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_validar_ferias BEFORE INSERT OR UPDATE ON public.lancamento_ferias FOR EACH ROW EXECUTE PROCEDURE public.validar_ferias();


--
-- Name: codigo_colaborador_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lancamento_ferias
    ADD CONSTRAINT codigo_colaborador_fkey FOREIGN KEY (codigo_colaborador) REFERENCES public.colaboradores(codigo) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: setor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT setor_fkey FOREIGN KEY (codigo_setor) REFERENCES public.setores(codigo) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

